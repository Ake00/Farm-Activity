public class Farm{
 Animal [] farm;
 int count;
 
 public Farm(int size){
  farm = new Animal[size];
  count = 0;
 }
 
 public Farm(){
  this(50);
 }
 
 public String toString(){
  StringBuffer sb = new StringBuffer();
  for(int i = 0; i < count; i++)
   sb.append(farm[i] +"\n");
  return sb.toString();
 }
 
 public void add(Animal a){
  farm[count++] = a;
 }
 
 public static void main(String [] args){
  Farm farm = new Farm();
  farm.add(new Cat("Luxkie",20,"Sphynx"));
  farm.add(new Cow("Danskie",10,"Brahman"));
  farm.add(new Dog("Soya",20,"Shitzu"));
  System.out.println("Name\tBreed\tAge\tSound");
  System.out.println(farm);
  
 }
}