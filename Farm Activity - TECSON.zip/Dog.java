public class Dog extends Animal{
  
  public Dog(String name, int age, String breed){
    super(name, age,breed);
  }
  
  public Dog(){}
  
  public String sound(){
   return ("Arf arf");
  }
  
  public String toString(){
   return super.toString() + "\t"+sound()+"\t";
  }
  
  public static void main(String [] args){
   Animal a = new Dog("Soya", 2,"shitzu");
   System.out.println("The dog is : " + a);
   System.out.println("The sound of the dog: ");
   a.sound();
  }
  
}